var url = 'https://weather-ydn-yql.media.yahoo.com/forecastrss';
var method = 'GET';
var app_id = 'Z2F4s77e';
var consumer_key = 'dj0yJmk9d0FNeVlmaEtjekMyJnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PWFj';
var consumer_secret = '3397348c937790ce89e2ff528561533a81f6f6eb';
var concat = '&';
var query = {'location': 'sunnyvale,ca', 'format': 'json'};
var oauth = {
    'oauth_consumer_key': consumer_key,
    'oauth_nonce': Math.random().toString(36).substring(2),
    'oauth_signature_method': 'HMAC-SHA1',
    'oauth_timestamp': parseInt(new Date().getTime() / 1000).toString(),
    'oauth_version': '1.0'
};

var merged = {}; 
$.extend(merged, query, oauth);
// Note the sorting here is required
var merged_arr = Object.keys(merged).sort().map(function(k) {
  return [k + '=' + encodeURIComponent(merged[k])];
});
var signature_base_str = method
  + concat + encodeURIComponent(url)
  + concat + encodeURIComponent(merged_arr.join(concat));

var composite_key = encodeURIComponent(consumer_secret) + concat;
var hash = CryptoJS.HmacSHA1(signature_base_str, composite_key);
var signature = hash.toString(CryptoJS.enc.Base64);

oauth['oauth_signature'] = signature;
var auth_header = 'OAuth ' + Object.keys(oauth).map(function(k) {
  return [k + '="' + oauth[k] + '"'];
}).join(',');

$.ajax({
  url: url + '?' + $.param(query),
  headers: {
    'Authorization': auth_header,
    'X-Yahoo-App-Id': app_id 
  },
  method: 'GET',
  success: function(data){
	  function displayWeather(data) {
		    var city = document.getElementById("city").value;
		    var state = document.getElementById("state").value;

		    if (city == "" && state == " ") {

		        document.getElementById("result").innerHTML = "Please Enter state and city";
		    }
		    var xmlhttp = new XMLHttpRequest();
		    xmlhttp.open("get", url, true);
		    xmlhttp.send();
		    xmlhttp.onreadystatechange = function () {

		        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

		            var w = JSON.parse(xmlhttp.responseText);
		            document.getElementById("result").innerHTML = "Current Temperature is " + w.data.results.channel.item.condition.temp + " " +
		                "<br/>" + "Looks: " + w.query.results.channel.item.condition.text + "" + "<br/>" + "Sunrise:" + w.data.results.channel.astronomy.sunrise + "" +
		                "<br/>" + "Sunset: " + w.query.results.channel.astronomy.sunset;

		        }
		    };
		}
  }
});




