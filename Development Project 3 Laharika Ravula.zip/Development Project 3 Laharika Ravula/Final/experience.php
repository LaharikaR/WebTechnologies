<!DOCTYPE html>
<html lang="en">
<head>
  <title>Experience</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>


<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="experience.php">Experience</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Contact.php">Contact</a>
      </li>    
    </ul>
  </div>  
</nav>
<div class="row">
      <div class="col-sm-6">
      	<h2>Tata Consultancy Services Pvt ltd</h2>
      	<h5>Systems Engineer(Oct 12,2015 to Dec 25, 2017)</h5>
      	<img src="https://media.glassdoor.com/l/75/d4/0f/60/tcs-hyderabad.jpg" class="img-thumbnail" alt="TCS" width="304" height="236">
	  <ul>
	  <li>Generated ad-hoc reports by running SQL queries against data warehouse.</li>
	  <li>Worked on the enhancement of Western Union (banking and financial sector) web application.</li>
	  <li>Worked on extracting Stored Procedures, tables, views along with other SQL joins on WU applications using SQL.</li>
	  </ul>
      </div>
      <div class="col-sm-6">
        <h2>Student worker</h2>
        <h5>Marist College, May 18, 2018 to present</h5>
	  <img src="https://wedo.org/wp-content/uploads/2017/02/Marist-College.jpg" class="rounded-circle" alt="Marist College" width="304" height="236">
	  <ul>
	    <li>Involved in deployment, used Git as a Source Code Repository to maintain and manage code reviews.</li>
	    <li>Performed regression testing, used JIRA to track defects and provide quality deliverable.</li>
	    <li>Worked extensively on the Learning Management System to manage business requirements.</li>
	  </ul>
      </div>
</div>
 
 
</div>
</body>