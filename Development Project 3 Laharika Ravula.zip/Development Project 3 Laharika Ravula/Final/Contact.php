<!DOCTYPE html>

<html lang="en">

<head>

	
<title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>  

<script>

function validateEmail(emailField){
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(emailField.value) == false) 
        {
            alert('Invalid Email Address');
            return false;
        }

        return true;
}

</script>


<style>


div.middle{
	
margin-left: 20%;
	
margin-top: 70px;
	
border:1px;
	
width: 800px;
	
height: 700px;
}

th, td {
    
padding: 15px;
}


</style>


</head>



<body>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="experience.php">Experience</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Contact.php">Contact</a>
      </li>    
    </ul>
  </div>  
</nav>
<div class="middle" align = "center">
	
<u><h2>ContactInfo</h2></u>



<form method="POST" name="myForm" action="Contact.php">
  
	<b>Name:</b><br>
  <input type="text" name="name" value="" required="required" placeholder="Enter Name">

	<br><br>
  
	<b>PhoneNumber:</b><br>
  <input type="text" name="Phone" value="" required="required" placeholder="Enter PhoneNumber">
  
	<br><br>
  
	<b>EmailID:</b>	<br>
 <input type="text" name="EmailID" value="" required="required" placeholder="Enter EmailID" onblur="validateEmail(this);">
  
	<br><br>
  
	<b>Message:</b><br>
 <textarea cols="57" rows="6" name="Message" placeholder="Message" required="required"></textarea>
  
	<br><br>
  
	<select id="ContactReason" name="ReasonOfContact"></select></br></br>
 
	<script Src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
          
	<script >
  var $select = $('#ContactReason');
              
		       $.getJSON('data.json', function(data){
                
                
				for (var i = 0; i < data['ContactReason'].length; i++) {$select.append('<option id="' + data['ContactReason'][i]['id'] + '">' 											+ data['ContactReason'][i]['name'] + '</option>');
 }
});
          
	</script>
  
	</br>
  
	<div class="send">
            
		<input type="submit" name="send" onsubmit="setTimeout(function () { window.location.reload(); }, 10)">
              
	</div>

</form> 

</div>


</body>


</html>



<?php

$link= mysqli_connect("localhost","root","","contact");

if (isset($_POST['send']))
 {
       
$name = $_POST['name'];
       
$Phone = ($_POST['Phone']);
       
$message = ($_POST['Message']);
       
$email = $_POST['EmailID'];
       
$roc = $_POST['ReasonOfContact'];

       
// Mail Stuff
       
$to = "laharikar@gmail.com";
       
$subject1 = "New Form Submitted";
       
$txt = "New Contact form has been Submitted";
       
$headers = "From: donotreply@abc.com" ;


       
date_default_timezone_set("America/New_York");
       
$timestamp = date('Y-m-d G:i:s');
       
       
if (isset($_POST['EmailID'])==true && empty($_POST['EmailID'])==false)
        
{
        
$email=$_POST['EmailID'];
        
if (filter_var($email,FILTER_VALIDATE_EMAIL)==true)
         
{ 
                    
                    
$query="INSERT INTO contactinfo(name,phno,email,message,roc,time_stamp) 
                    
values ('$name','$Phone','$email','$message','$roc','$timestamp')";
                    
$stmt=$link->prepare($query);
                    
if($stmt->execute()==true)
                        
{
                             
mail($to,$subject1,$txt,$headers);
                             
echo "<script>alert(' Submitted Successful')</script>";
                             
EXIT();
                             
//header('Location:index.php');
                        
}
                
        
    
}
       
 else
        
{
            
echo "<script>alert('Invalid Email Address')</script>";
            
die();
        
}
    
}
}
?>