<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  </head>
<body>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="experience.php">Experience</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Contact.php">Contact</a>
      </li>    
    </ul>
  </div>  
</nav>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-8">
      <h2>About Me</h2>
      <h5>Below is my picture</h5>
      <div class="imagesContainer"><img src="Laharika.jpg" alt="My image" style="width:190px;height:220px;">


</div>

	<p>I am graduate student - pursuing masters in Masters of science in information systems at Marist College</p>
      </div>
      <div class="col-sm-4">
       <h3>Few links</h3>
	    <ul class="nav nav-pills flex-column">
               <li class="nav-item">
                 <a class="nav-link" href="https://www.linkedin.com/in/laharikaravula/">LinkedIn</a>
               </li>
               <li class="nav-item">
                 <a class="nav-link" href="https://github.com/LaharikaR/WebTechnologies">Github</a>
               </li>
               <li class="nav-item">
                 <a class="nav-link disabled" href="https://www.facebook.com/">Disabled Facebook</a>
               </li>
            </ul>
        <hr class="d-sm-none">
      </div>
   </div>
</div>
<div>

	<a href="Resume.pdf" class="button" download style="color: rgb(255,255,255); text-decoration:none;background-color: #bf5050; border: none;
color: white;
   padding: 15px 32px;
    text-align: center;
 display: inline-block;
    font-size: 16px;
    margin-left: 45%;
    margin-top: 4%;">Download Resume</a>

</div>

<div class="container">
  <footer>Rights Reserved � Laharika Ravula</footer>
</div>

</body>
</html>
